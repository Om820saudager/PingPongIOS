using System.IO;
using System.Reflection;
using UnityEngine;

public class LeaderBoardManager : MonoBehaviour
{
    public LeaderBoard leaderBoard;
    public GameManager gameManager;

    string filePath;

    void Start()
    {
        filePath = Application.persistentDataPath + "/leaderBoard.json";
        
    }

    public void SaveLeaderBoard()
    {
        string json = JsonUtility.ToJson(leaderBoard);
        File.WriteAllText(filePath, json);
    }

    public void LoadLeaderBoard()
    {
        if(File.Exists(filePath))
        {
            string json = File.ReadAllText(filePath);   
            leaderBoard = JsonUtility.FromJson<LeaderBoard>(json);
        }

        else
        {
            leaderBoard = new LeaderBoard();
        }
    }

    public void AddScore(string playerName, int score)
    {
       LeaderBoardData newScore = new LeaderBoardData { playerName = playerName, score = score };

        leaderBoard.topScore.Add(newScore);

        leaderBoard.topScore.Sort((x, y) => y.score.CompareTo(x.score));

        if (leaderBoard.topScore.Count > 10 )
        {
            leaderBoard.topScore.RemoveAt(leaderBoard.topScore.Count - 1); // limits the top score to be max 10.
        }

        SaveLeaderBoard();
    }

}
