
using System.Collections.Generic;

[System.Serializable]
public class LeaderBoardData 
{
    public string playerName;
    public int score;

    public LeaderBoardData()
    {
        playerName = "";
        score = 0;
    }
}

[System.Serializable]
public class LeaderBoard
{
    public List<LeaderBoardData> topScore = new List<LeaderBoardData>();
}
