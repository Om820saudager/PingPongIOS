using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerPaddleController : MonoBehaviour
{
    [Header("Positions")]
    [SerializeField] float speed = 10f;
    [SerializeField] float boundaryY = 3.8f;

    // Update is called once per frame
    void Update()
    {
        float verticalInput = 0f;

        if (Input.GetKey(KeyCode.UpArrow))
        {
            verticalInput = 1f;
        }

        else if (Input.GetKey(KeyCode.DownArrow))
        {
            verticalInput = -1f;
        }

        //float verticalInput = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3 (0, verticalInput * speed * Time.deltaTime, 0);
        transform.position += movement;


        float clampedY = Mathf.Clamp(transform.position.y, -boundaryY, boundaryY);
        transform.position = new Vector3(transform.position.x, clampedY, transform.position.z);
    }
}
