using System.Collections;
using System.Collections.Generic;
using UnityEditor.Build.Content;
using UnityEngine;

public class ResetBall : MonoBehaviour
{

    public GameManager GameManager;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Ball"))
        {
          if(transform.position.x < 0)
            {
                GameManager.PlayerScored();
            }

          else
            {
                GameManager.OpponentScored();
            }

            BallController ballController = collision.GetComponent<BallController>();
            if (ballController != null)
            {
                ballController.BallReset(); // Reset the ball
            }
        }
    }
}
