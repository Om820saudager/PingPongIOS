// no need for the monobehavior and namespaces as it's just a class to hold data, System.Serializable allows class to converted to JSON

[System.Serializable]
public class PlayerScores 
{
    public int playerScore;
    public int opponentScore;
}
